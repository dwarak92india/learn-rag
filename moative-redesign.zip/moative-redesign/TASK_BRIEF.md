# Moative website redesign — task brief for evaluation

**Constraint:** Do not change the content. Lift the design.
**Source of truth:** https://www.moative.com/
**Prototype:** this folder (`index.html`, `bastion.html`, `about.html`, `contact.html`)

---

## 1. What this task is

Take the live Moative main pages and rebuild their visual system so the site sits in the same league as Future Works, RealFast, Tribe, Build, and June — without rewriting headlines, product names, metrics, or thesis copy.

This is a **design implementation task**, not a messaging task.

## 2. Pages in scope

| Page | Live URL | Prototype file |
|---|---|---|
| Home | https://www.moative.com/ | `index.html` |
| Bastion / platform | https://www.moative.com/ai-platform-for-midmarket/ | `bastion.html` |
| About | https://www.moative.com/about/ | `about.html` |
| Contact | https://www.moative.com/contact | `contact.html` |

Out of scope for this pass: blog, RoundTable, Foundry long-form, legal pages. They should inherit tokens later.

## 3. Hard rules

1. Keep original words. Tightening line breaks is allowed. New slogans are not.
2. Keep product names: Bastion, Spoggle, Cortex, Courier, Lisa, Assay, Almanac, TailML, SpaceML, PriceML, ResidualML, Crucible, Brief.
3. Keep CTAs: “Get us on the floor”, “You take the shot. We take the assist.”
4. Keep metrics and case names (PipeCandy, Exceleron, etc.).
5. Do not turn Moative into a purple-gradient AI agency or a robot-on-a-hill lab.

## 4. Design system to implement

**Position:** Quant studio × industrial operator × editorial house.

| Token | Value |
|---|---|
| Canvas | Warm paper `#F3EEE6` — not printer white |
| Ink | `#161410` |
| Accent | Rust `#B4532A` |
| Dark band | Ink green `#141C19` |
| Highlight | Pale gold `#E7D7A8` behind 3–5 phrases only |
| Display type | Newsreader (editorial serif) |
| UI / body | Outfit |
| Labels | IBM Plex Mono, tracked uppercase |
| Radius | 16–22px cards, pill buttons |
| Buttons | Primary rust or ink. Secondary ghost. Dual CTA on hero. |

**Art direction**
- Industrial photography for verticals and How it works (energy, clinic, mill, yard, operators).
- Abstract orbital / systems drawing in the hero — not a neural-net cliché.
- Bento grid for the platform.
- Scoreboard for outcomes.
- Cookie UI as a corner card, never a full-width slab over logos.

## 5. Section mapping (home)

Same sections, new objects:

1. Slim sticky header + thin OpenAI rail
2. Split hero: type left, visual right, punchline highlighted
3. Logo proof as a row, not trapped under cookies
4. Foundation as portrait + three chips
5. Platform as dark bento
6. How it works as three photo cards (fix the empty frames)
7. Verticals as four image tiles
8. Outcomes as big-number scoreboard + two case cards + pull quote
9. Dark closer as six editorial boxes
10. Footer as a quiet index

## 6. What “done” looks like

- A mid-market CEO can understand the offer in one screen.
- Platform IP feels like a product, not a bullet list.
- How-it-works no longer looks unfinished.
- Numbers are the loudest proof on the page.
- Paper / rust / serif language is consistent across Home, Bastion, About, Contact.
- Mobile: single column, header collapses, type still large.

## 7. Effort estimate for a design + front-end pair

| Slice | Time |
|---|---|
| Tokens, type, chrome, cookie | 1–2 days |
| Home sections | 4–6 days |
| Bastion + About + Contact | 3–4 days |
| Photography direction / commission | 3–5 days parallel |
| Motion (marquee, count-up, hover) | 2 days |
| QA + inner-page inheritance | 2 days |

**Total: about 2–3 weeks** for a high-fidelity production pass. This prototype is the look target, not production code.

## 8. How to evaluate this prototype

Open `index.html` first. Walk this checklist:

- [ ] Does the hero feel like an operating partner, not a blog post?
- [ ] Is the punchline the most memorable line on the page?
- [ ] Does the platform bento make Bastion feel real?
- [ ] Do Depute / Deploy / Play to win finally have weight?
- [ ] Do the four verticals feel like different rooms?
- [ ] Do 3.21% / 45s / 40min / 8% land before the case paragraphs?
- [ ] Does About still read as a thesis-driven firm?
- [ ] Would you send this URL to a PE-backed mid-market CEO?

If yes on most, the task is correctly specified. Production then replaces stock photos with directed photography and wires the real CMS.
